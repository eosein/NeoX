/* =========================================================
   NeoX Studio — main.js
   ========================================================= */
'use strict';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)');
const finePointer = window.matchMedia('(hover:hover) and (pointer:fine)');

/* localStorage seguro (nunca quebra o site) */
const store = {
    get(k){ try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
    set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
    del(k){ try { localStorage.removeItem(k); } catch {} }
};

/* =========================================================
   CONFIGURAÇÃO (edite aqui)
   ========================================================= */
const PLACES = { ap:'96665881849072', cr:'111173250236559', ff:'93233198656969' };
const ROBLOX_GROUP_ID = '35039927';
const DISCORD_INVITE  = 'animeparadiseee';
const STATS_INTERVAL  = 30000;   // jogadores, curtidas, favoritos, visitas
const COMMUNITY_INTERVAL = 60000; // grupo do Roblox + Discord

// Formulário: use UMA das opções. Se ambas ficarem vazias, o site avisa que o formulário não está ativo.
const CONTACT_WORKER_URL = '';   // Opção A: URL do seu Cloudflare Worker
const FORMSUBMIT_ID = '';        // Opção B: código aleatório do FormSubmit (e-mail de ativação)

/* Equipe: para adicionar alguém, é só incluir uma linha aqui. id = número do perfil no Roblox (ou null) */
const TEAM = [
    { name:'SasaDev', role:'role_owner',      img:'assets/sasa.png',   id:'5790284269' },
    { name:'DaviDev', role:'role_coowner_gd', img:'assets/davi.png',   id:'1213557895' },
    { name:'oSein',   role:'role_gd',         img:'assets/osein.png',  id:'4565735367' },
    { name:'Slow',    role:'role_animator',   img:'assets/slow.png',   id:'2620031389' },
    { name:'Flex',    role:'role_modeler',    img:'assets/flex.png',   id:'2362898887' },
    { name:'Oguest',  role:'role_vfx',        img:'assets/oguest.png', id:'8093384811' },
    { name:'Reject',  role:'role_ui',         img:'assets/reject.png', id:null },
    { name:'Moon',    role:'role_cm',         img:'assets/moon.png',   id:'1587723048' }
];

/* =========================================================
   1. TRADUÇÕES
   ========================================================= */
const i18n = {
    pt: {
        skip:'Pular para o conteúdo',
        nav_home:'Home', nav_about:'Sobre', nav_games:'Jogos', nav_media:'Trailers', nav_team:'Equipe', nav_contact:'Contato',
        hero_tag:'Criando Universos Inesquecíveis',
        hero_title_1:'Jogos com energia, cores e', hero_title_2:'pura diversão.',
        hero_desc:'A NeoX é onde a comunidade ganha vida. Desenvolvemos experiências imersivas de alto nível no ecossistema Roblox.',
        btn_explore:'Conhecer Jogos', btn_discord:'Entrar no Discord',
        stat_1:'Jogadores agora', stat_2:'Total de curtidas', stat_3:'Total de favoritos', stat_4:'Visitas totais',
        about_tag:'A Nossa Essência', about_title:'Diversão levada a sério.',
        about_desc:'A NeoX nasceu para quebrar a monotonia. Nós não fazemos apenas jogos, criamos parques de diversão digitais onde cada pixel, animação e mecânica são pensados para surpreender.',
        feat_1_title:'Gameplay Vibrante', feat_1_desc:'Ação dinâmica e fluida.',
        feat_2_title:'Comunidade Ativa', feat_2_desc:'Ouvimos cada jogador.',
        feat_3_title:'Updates Constantes', feat_3_desc:'Atualizações frequentes.',
        about_box_title:'Inovação em Cada Detalhe',
        about_box_desc:'Nossa equipe reúne talentos de ponta em design de interfaces, programação avançada em Luau, animações 3D e modelagem para entregar o mais alto padrão do Roblox Studio.',
        grp_name:'Grupo no Roblox', grp_label:'Membros no grupo da NeoX', grp_sub:'Entre e acompanhe cada novidade.',
        dc_name:'Comunidade no Discord', dc_label:'Membros no servidor', online:'online agora',
        games_tag:'O Que Jogar Agora', games_title:'Nossos Universos',
        games_subtitle:'Explore o portfólio de jogos oficiais desenvolvidos pela NeoX Studio.',
        badge_dev:'Em Desenvolvimento', playing:'jogando', visits:'Visitas', likes:'Curtidas', favs:'Favoritos',
        game_1_desc:'Explore mundos inspirados em animes, derrote inimigos e recrute campeões poderosos.',
        game_2_desc:'Entre na arena e prove seu valor no jogo de ação mais frenético e competitivo do ano.',
        game_3_desc:'Entre em uma experiência intensa de combate tático, estratégia e sobrevivência no ecossistema Roblox.',
        btn_play:'Jogar Agora', btn_preview:'Ver Projeto', game_discord:'Discord do Jogo', discord_soon:'Discord em breve',
        media_tag:'Cinemáticas & Demonstrativos', media_title:'Mídia Oficial',
        media_subtitle:'Demonstrações e conceitos visuais dos projetos NeoX Studio.',
        ac_1_tag:'Gameplay Oficial', ac_1_title:'Combate & Movimentação',
        ac_2_tag:'Sistema de Quests', ac_2_title:'Missões & Recompensas',
        ac_3_tag:'Interface & Habilidades', ac_3_title:'Árvore de Skills',
        ap_title:'Anime Paradise — Prévias', peek_1:'Prévia 01', peek_2:'Prévia 02', peek_3:'Prévia 03',
        media_cutscene_ui:'Cinemática & UI', media_movement:'Movimentação', media_models:'Modelos',
        media_soon:'Mídia em breve',
        team_tag:'Os Criadores', team_title:'A Equipe NeoX',
        team_subtitle:'Mentes brilhantes unidas para construir o futuro dos jogos no Roblox.',
        role_owner:'Proprietário', role_coowner_gd:'Coproprietário & Designer de Jogos', role_gd:'Designer de Jogos',
        role_animator:'Animador', role_modeler:'Modelador', role_vfx:'Artista de VFX', role_ui:'Designer de UI/UX', role_cm:'Gerente da Comunidade',
        profile:'Perfil Roblox',
        contact_tag:'Fale Conosco', contact_title:'Pronto para a diversão?',
        contact_subtitle:'Mande uma mensagem, entre no nosso Discord e faça parte da família NeoX!',
        form_name:'Seu Nome', form_email:'Seu E-mail', form_roblox:'Nick do Roblox (Opcional)',
        form_msg:'Mensagem (Mínimo 16 caracteres)', form_btn:'Enviar Mensagem',
        official_discord:'Discord Oficial', footer:'© 2026 NeoX. Todos os direitos reservados.',
        stats_loading:'Carregando dados do Roblox…',
        stats_unavailable:'Dados do Roblox indisponíveis no momento.',
        stats_updated:t=>`Dados do Roblox atualizados às ${t} · atualização a cada ~30 s`,
        sending:'Enviando…', sent:'Mensagem enviada!', send_error:'Não foi possível enviar. Tente novamente.',
        form_inactive:'O formulário ainda não está ativo. Fale com a gente no Discord!',
        team_prev:'Desenvolvedor anterior', team_next:'Próximo desenvolvedor',
        aria_menu_open:'Abrir menu', aria_menu_close:'Fechar menu', title:'NeoX Studio | Jogue o Futuro'
    },
    en: {
        skip:'Skip to content',
        nav_home:'Home', nav_about:'About', nav_games:'Games', nav_media:'Trailers', nav_team:'Team', nav_contact:'Contact',
        hero_tag:'Crafting Unforgettable Universes',
        hero_title_1:'Games with energy, colors and', hero_title_2:'pure fun.',
        hero_desc:'NeoX is where community comes alive. We develop high-end immersive experiences in the Roblox ecosystem.',
        btn_explore:'Explore Games', btn_discord:'Join Discord',
        stat_1:'Players online', stat_2:'Total Likes', stat_3:'Total Favorites', stat_4:'Total Visits',
        about_tag:'Our Essence', about_title:'Fun taken seriously.',
        about_desc:'NeoX was born to break monotony. We don’t just make games, we create digital amusement parks where every pixel, animation and mechanic is designed to surprise.',
        feat_1_title:'Vibrant Gameplay', feat_1_desc:'Dynamic and fluid action.',
        feat_2_title:'Active Community', feat_2_desc:'We listen to every player.',
        feat_3_title:'Constant Updates', feat_3_desc:'Frequent updates.',
        about_box_title:'Innovation in Every Detail',
        about_box_desc:'Our team brings together top talent in UI design, advanced Luau programming, 3D animation and modeling to deliver the highest standard in Roblox Studio.',
        grp_name:'Roblox Group', grp_label:'Members in the NeoX group', grp_sub:'Join in and follow every update.',
        dc_name:'Discord Community', dc_label:'Members in the server', online:'online now',
        games_tag:'What To Play Now', games_title:'Our Universes',
        games_subtitle:'Explore the portfolio of official games developed by NeoX Studio.',
        badge_dev:'In Development', playing:'playing', visits:'Visits', likes:'Likes', favs:'Favorites',
        game_1_desc:'Explore anime-inspired worlds, defeat enemies and recruit powerful champions.',
        game_2_desc:'Enter the arena and prove your worth in the most frenetic and competitive action game of the year.',
        game_3_desc:'Step into an intense tactical combat, strategy and survival experience in the Roblox ecosystem.',
        btn_play:'Play Now', btn_preview:'View Project', game_discord:'Game Discord', discord_soon:'Discord coming soon',
        media_tag:'Cinematics & Showcases', media_title:'Official Media',
        media_subtitle:'Demonstrations and visual concepts of NeoX Studio projects.',
        ac_1_tag:'Official Gameplay', ac_1_title:'Combat & Movement',
        ac_2_tag:'Quest System', ac_2_title:'Missions & Rewards',
        ac_3_tag:'Interface & Abilities', ac_3_title:'Skill Tree',
        ap_title:'Anime Paradise — Sneak Peeks', peek_1:'Sneak Peek 01', peek_2:'Sneak Peek 02', peek_3:'Sneak Peek 03',
        media_cutscene_ui:'Cutscene & UI', media_movement:'Movement', media_models:'Models',
        media_soon:'Media coming soon',
        team_tag:'The Creators', team_title:'The NeoX Team',
        team_subtitle:'Brilliant minds united to build the future of Roblox games.',
        role_owner:'Owner', role_coowner_gd:'Co-Owner & Game Designer', role_gd:'Game Designer',
        role_animator:'Animator', role_modeler:'Modeler', role_vfx:'VFX Artist', role_ui:'UI/UX Designer', role_cm:'Community Manager',
        profile:'Roblox Profile',
        contact_tag:'Get in Touch', contact_title:'Ready for the fun?',
        contact_subtitle:'Send a message, join our Discord and be part of the NeoX family!',
        form_name:'Your Name', form_email:'Your Email', form_roblox:'Roblox Username (Optional)',
        form_msg:'Message (Minimum 16 characters)', form_btn:'Send Message',
        official_discord:'Official Discord', footer:'© 2026 NeoX. All rights reserved.',
        stats_loading:'Loading Roblox stats…',
        stats_unavailable:'Roblox stats are unavailable right now.',
        stats_updated:t=>`Roblox stats updated at ${t} · refreshes about every 30 s`,
        sending:'Sending…', sent:'Message sent!', send_error:'Could not send. Please try again.',
        form_inactive:'The contact form isn’t active yet. Reach us on Discord!',
        team_prev:'Previous developer', team_next:'Next developer',
        aria_menu_open:'Open menu', aria_menu_close:'Close menu', title:'NeoX Studio | Play the Future'
    }
};

function detectLang(){
    const saved = store.get('neox-lang');
    if (saved === 'pt' || saved === 'en') return saved;
    return (navigator.language || 'pt').toLowerCase().startsWith('pt') ? 'pt' : 'en';
}
let currentLang = detectLang();
const locale = () => currentLang === 'pt' ? 'pt-BR' : 'en-US';
const tr = key => i18n[currentLang][key];

function applyLanguage(lang){
    currentLang = lang;
    const t = i18n[lang];
    $$('[data-i18n]').forEach(el => { const v = t[el.dataset.i18n]; if (typeof v === 'string') el.textContent = v; });
    document.documentElement.lang = lang === 'pt' ? 'pt-BR' : 'en';
    document.title = t.title;
    $('#lang-label').textContent = lang === 'pt' ? 'PT-BR' : 'EN';
    updateMenuLabel();
    $('#team-prev')?.setAttribute('aria-label', t.team_prev);
    $('#team-next')?.setAttribute('aria-label', t.team_next);
    $$('.media-placeholder').forEach(p => { p.textContent = t.media_soon; });
    renderStatsNote();
    store.set('neox-lang', lang);
}
$('#lang-btn').addEventListener('click', () => {
    applyLanguage(currentLang === 'pt' ? 'en' : 'pt');
    if (lastSnapshot) renderStats(lastSnapshot);
    renderCommunity();
});

/* =========================================================
   2. MENU MOBILE
   ========================================================= */
const menuBtn = $('#menu-btn'), mobileMenu = $('#mobile-menu'), menuIcon = $('#menu-icon');
function updateMenuLabel(){
    const open = menuBtn.getAttribute('aria-expanded') === 'true';
    menuBtn.setAttribute('aria-label', open ? tr('aria_menu_close') : tr('aria_menu_open'));
}
function setMenu(open){
    mobileMenu.classList.toggle('is-open', open);
    menuBtn.setAttribute('aria-expanded', String(open));
    menuIcon.className = open ? 'fa-solid fa-xmark' : 'fa-solid fa-bars';
    mobileMenu.inert = !open;
    updateMenuLabel();
}
setMenu(false);
menuBtn.addEventListener('click', () => setMenu(menuBtn.getAttribute('aria-expanded') !== 'true'));
$$('a', mobileMenu).forEach(a => a.addEventListener('click', () => setMenu(false)));
document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });
window.matchMedia('(min-width:768px)').addEventListener('change', e => { if (e.matches) setMenu(false); });
document.addEventListener('click', e => { if (menuBtn.getAttribute('aria-expanded') === 'true' && !e.target.closest('.site-header')) setMenu(false); });

/* Pulso ao clicar no menu */
$$('.site-header a[href^="#"]').forEach(link => link.addEventListener('click', () => {
    const section = $(link.getAttribute('href'));
    link.classList.remove('nav-click-pulse'); section?.classList.remove('section-arrival');
    void link.offsetWidth;
    link.classList.add('nav-click-pulse'); section?.classList.add('section-arrival');
    setTimeout(() => { link.classList.remove('nav-click-pulse'); section?.classList.remove('section-arrival'); }, 850);
}));

/* =========================================================
   3. PROGRESSO DE ROLAGEM, HEADER E LINK ATIVO
   ========================================================= */
(function(){
    const bar = $('#scroll-progress'), header = $('#site-header');
    const links = $$('.nav-desktop .nav-link');
    const sections = links.map(a => $(a.getAttribute('href'))).filter(Boolean);
    let ticking = false;
    function update(){
        ticking = false;
        const doc = document.documentElement;
        const max = doc.scrollHeight - window.innerHeight;
        bar.style.transform = `scaleX(${max > 0 ? Math.min(1, window.scrollY / max) : 0})`;
        header.classList.toggle('is-scrolled', window.scrollY > 24);
        let current = sections[0]?.id || '';
        sections.forEach(s => { if (s.getBoundingClientRect().top <= window.innerHeight * .35) current = s.id; });
        if (window.innerHeight + window.scrollY >= doc.scrollHeight - 4 && sections.length) current = sections[sections.length - 1].id;
        links.forEach(a => a.classList.toggle('is-active', a.getAttribute('href') === '#' + current));
    }
    window.addEventListener('scroll', () => { if (!ticking){ ticking = true; requestAnimationFrame(update); } }, { passive:true });
    window.addEventListener('resize', update, { passive:true });
    update();
})();

/* =========================================================
   4. REVELAR AO ROLAR (escalonado) — elementos com [data-reveal]
   ========================================================= */
(function(){
    const targets = $$('[data-reveal]');
    if (prefersReduced.matches || !('IntersectionObserver' in window)) return;
    const finish = el => { el.classList.remove('reveal', 'is-in'); el.style.removeProperty('--d'); };
    const io = new IntersectionObserver(entries => entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        io.unobserve(el);
        el.classList.add('is-in');
        let done = false;
        const end = () => { if (done) return; done = true; finish(el); };
        el.addEventListener('transitionend', e => { if (e.target === el && e.propertyName === 'opacity') setTimeout(end, 30); });
        setTimeout(end, 2000); // rede de segurança
    }), { threshold:.08, rootMargin:'0px 0px -6% 0px' });
    targets.forEach(el => {
        const sibs = Array.from(el.parentElement.children).filter(c => c.hasAttribute('data-reveal'));
        el.style.setProperty('--d', Math.min(sibs.indexOf(el), 5) * 90 + 'ms');
        el.classList.add('reveal');
        io.observe(el);
    });
    setTimeout(() => targets.forEach(el => el.classList.add('is-in')), 5000); // nada fica invisível
})();

/* =========================================================
   5. PARTÍCULAS
   ========================================================= */
(function(){
    const canvas = $('#particle-canvas'), ctx = canvas.getContext('2d');
    const colors = ['rgba(53,196,229,.32)', 'rgba(0,229,255,.24)', 'rgba(53,196,229,.22)', 'rgba(244,91,155,.16)'];
    let w = 0, h = 0, particles = [], raf = null;
    const make = () => ({ x:Math.random()*w, y:Math.random()*h, s:Math.random()*2+1, vx:(Math.random()-.5)*.45, vy:(Math.random()-.5)*.45,
                          c: Math.random() < .08 ? colors[3] : colors[Math.floor(Math.random()*3)] });
    function resize(){
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        w = window.innerWidth; h = window.innerHeight;
        canvas.width = w * dpr; canvas.height = h * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const count = w < 640 ? 18 : 48;
        while (particles.length < count) particles.push(make());
        particles.length = count;
        particles.forEach(p => { p.x = Math.min(p.x, w); p.y = Math.min(p.y, h); });
    }
    function draw(){
        ctx.clearRect(0, 0, w, h);
        for (const p of particles){
            p.x += p.vx; p.y += p.vy;
            if (p.x < 0 || p.x > w) p.vx *= -1;
            if (p.y < 0 || p.y > h) p.vy *= -1;
            ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2); ctx.fill();
        }
    }
    const loop = () => { draw(); raf = requestAnimationFrame(loop); };
    const start = () => { if (!raf && !prefersReduced.matches) loop(); };
    const stop = () => { if (raf) cancelAnimationFrame(raf); raf = null; };
    resize();
    let lastW = window.innerWidth;
    window.addEventListener('resize', () => { if (window.innerWidth === lastW) return; lastW = window.innerWidth; resize(); if (prefersReduced.matches) draw(); }, { passive:true });
    document.addEventListener('visibilitychange', () => document.hidden ? stop() : start());
    prefersReduced.addEventListener('change', () => { stop(); prefersReduced.matches ? draw() : start(); });
    prefersReduced.matches ? draw() : start();
})();

/* =========================================================
   6. EFEITOS DE CARD (spotlight + inclinação suave) — só mouse
   ========================================================= */
(function(){
    if (prefersReduced.matches) return;
    let active = null, raf = 0, ev = null;
    function reset(el){ if (!el) return; el.style.removeProperty('--rx'); el.style.removeProperty('--ry'); }
    function apply(){
        raf = 0;
        if (!ev) return;
        const card = ev.target.closest ? ev.target.closest('.spot') : null;
        if (card !== active){ reset(active); active = card; }
        if (!card) return;
        const r = card.getBoundingClientRect();
        const x = ev.clientX - r.left, y = ev.clientY - r.top;
        card.style.setProperty('--mx', x + 'px'); card.style.setProperty('--my', y + 'px');
        if (card.classList.contains('tilt')){
            card.style.setProperty('--ry', ((x / r.width - .5) * 6).toFixed(2) + 'deg');
            card.style.setProperty('--rx', ((.5 - y / r.height) * 5).toFixed(2) + 'deg');
        }
    }
    function bind(){
        if (!finePointer.matches) return;
        document.addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; ev = e; if (!raf) raf = requestAnimationFrame(apply); }, { passive:true });
        document.addEventListener('pointerleave', () => { reset(active); active = null; });
    }
    bind();
})();

/* =========================================================
   7. MÍDIA: vídeos em loop contínuo (estilo GIF) + imagens faltando
   ========================================================= */
function showMediaPlaceholder(el){
    if (el.dataset.missing) return;
    el.dataset.missing = '1';
    const ph = document.createElement('div');
    ph.className = 'media-placeholder';
    ph.textContent = tr('media_soon');
    el.style.display = 'none';
    el.parentNode.insertBefore(ph, el);
}

$$('img[data-fallbacks]').forEach(img => {
    const queue = img.dataset.fallbacks.split(',').map(s => s.trim()).filter(Boolean);
    const next = () => { const n = queue.shift(); if (n) img.src = n; else showMediaPlaceholder(img); };
    img.addEventListener('error', next);
    if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) next();
});

(function(){
    const videos = $$('video.loop-video');
    if (!videos.length) return;
    const waiting = new Set();
    const state = new WeakMap(); // true = deve estar tocando

    function play(v){
        const p = v.play();
        if (p && p.catch) p.catch(() => waiting.add(v));
    }
    videos.forEach(v => {
        v.muted = true; v.defaultMuted = true; v.loop = true; v.playsInline = true; v.autoplay = true;
        v.controls = false; v.removeAttribute('controls');
        v.setAttribute('muted', ''); v.setAttribute('playsinline', '');
        v.setAttribute('controlsList', 'nodownload nofullscreen noremoteplayback');
        v.addEventListener('contextmenu', e => e.preventDefault());
        // Se algo pausar o vídeo sem o site mandar (ex.: modo economia), ele retoma sozinho
        v.addEventListener('pause', () => { if (state.get(v) && !document.hidden) play(v); });
        v.addEventListener('canplay', () => { if (state.get(v) && v.paused) play(v); });
        const sources = $$('source', v), last = sources[sources.length - 1];
        if (last) last.addEventListener('error', () => showMediaPlaceholder(v));
    });

    if (!('IntersectionObserver' in window)){ videos.forEach(v => { state.set(v, true); play(v); }); return; }

    // 1) Pré-carrega com folga, assim o vídeo já está pronto quando aparece (sem atraso)
    const preload = new IntersectionObserver(entries => entries.forEach(e => {
        if (!e.isIntersecting) return;
        const v = e.target;
        preload.unobserve(v);
        v.preload = 'auto';
        v.load();
        if (state.get(v)) play(v);
    }), { rootMargin:'1400px 0px' });

    // 2) Toca enquanto está perto da tela, pausa só quando está longe (invisível para a pessoa)
    const visible = new IntersectionObserver(entries => entries.forEach(e => {
        const v = e.target;
        if (e.isIntersecting){ state.set(v, true); play(v); }
        else { state.set(v, false); v.pause(); waiting.delete(v); }
    }), { rootMargin:'200px 0px', threshold:0 });

    videos.forEach(v => { preload.observe(v); visible.observe(v); });

    const retry = () => { waiting.forEach(v => play(v)); waiting.clear(); };
    ['touchstart','pointerdown','keydown','scroll','click'].forEach(name => window.addEventListener(name, retry, { passive:true }));
    document.addEventListener('visibilitychange', () => { if (!document.hidden) videos.forEach(v => { if (state.get(v)) play(v); }); });
})();

/* =========================================================
   8. ESTATÍSTICAS DO ROBLOX (tempo real)
      Ordem: (1) ao vivo via RoProxy  (2) roblox-stats.json  (3) último valor salvo
   ========================================================= */
let statsTimer = null, lastSnapshot = null, statsFailed = false;

async function fetchJSON(url, timeout = 8000){
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeout);
    try {
        const r = await fetch(url, { signal:ctrl.signal, cache:'no-store' });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return await r.json();
    } finally { clearTimeout(t); }
}
const num = v => (v == null || v === '' || !Number.isFinite(Number(v))) ? null : Number(v);
const FIELDS = ['playing', 'visits', 'likes', 'favorites'];
const hasData = s => !!(s && s.games && Object.values(s.games).some(g => g && FIELDS.some(f => num(g[f]) !== null)));

/* Une o novo resultado com o último valor conhecido: se UM campo falhar (ex.: curtidas), ele não some */
function mergeSnapshot(next, prev){
    const out = { updatedAt: next.updatedAt || new Date().toISOString(), games:{} };
    for (const key of Object.keys(PLACES)){
        out.games[key] = {};
        for (const f of FIELDS){
            const n = num(next.games?.[key]?.[f]);
            out.games[key][f] = n !== null ? n : num(prev?.games?.[key]?.[f]);
        }
    }
    return out;
}

const UNI_KEY = 'neox-universes-v3', UNI_TTL = 3 * 24 * 60 * 60 * 1000;
async function resolveUniverses(){
    const saved = store.get(UNI_KEY);
    const ids = (saved && saved.savedAt && Date.now() - saved.savedAt < UNI_TTL && saved.ids) ? saved.ids : {};
    let changed = false;
    await Promise.all(Object.values(PLACES).map(async place => {
        if (ids[place]) return;
        try {
            const d = await fetchJSON(`https://apis.roproxy.com/universes/v1/places/${place}/universe`);
            if (d && d.universeId){ ids[place] = d.universeId; changed = true; }
        } catch (e) { console.warn('[NeoX] universo não resolvido:', place, e.message); }
    }));
    if (changed) store.set(UNI_KEY, { savedAt:Date.now(), ids });
    return ids;
}

/* Curtidas: tenta o endpoint em lote e, para quem faltar, o endpoint individual */
async function fetchVotes(ids){
    const map = {};
    try {
        const d = await fetchJSON(`https://games.roproxy.com/v1/games/votes?universeIds=${ids.join(',')}`);
        (d.data || []).forEach(v => { if (num(v.upVotes) !== null) map[v.id] = v; });
    } catch (e) { console.warn('[NeoX] curtidas (lote) falharam:', e.message); }
    const missing = ids.filter(id => !map[id]);
    await Promise.all(missing.map(async id => {
        try {
            const v = await fetchJSON(`https://games.roproxy.com/v1/games/${id}/votes`);
            if (v && num(v.upVotes) !== null) map[id] = v;
        } catch (e) { console.warn('[NeoX] curtidas individuais falharam:', id, e.message); }
    }));
    return map;
}

async function fetchLive(){
    const uni = await resolveUniverses();
    const ids = Object.values(PLACES).map(p => uni[p]).filter(Boolean);
    if (!ids.length) throw new Error('nenhum universeId resolvido');
    const [gamesRes, votes] = await Promise.all([
        fetchJSON(`https://games.roproxy.com/v1/games?universeIds=${ids.join(',')}`),
        fetchVotes(ids)
    ]);
    const byId = {};
    (gamesRes.data || []).forEach(g => { byId[g.id] = g; });
    const games = {};
    for (const [key, place] of Object.entries(PLACES)){
        const id = uni[place], g = byId[id];
        games[key] = {
            playing: g ? g.playing : null, visits: g ? g.visits : null, favorites: g ? g.favoritedCount : null,
            likes: votes[id] ? votes[id].upVotes : null
        };
    }
    return { updatedAt:new Date().toISOString(), games };
}

/* Número animado: vai do valor atual até o novo */
function setNumber(el, value){
    if (typeof el === 'string') el = document.getElementById(el);
    if (!el) return;
    cancelAnimationFrame(el._raf);
    const fmt = n => new Intl.NumberFormat(locale(), el.dataset.compact ? { notation:'compact', maximumFractionDigits:1 } : {}).format(n);
    if (value === null || value === undefined){ el.textContent = '—'; el.dataset.value = ''; return; }
    const from = el.dataset.value ? Number(el.dataset.value) : 0;
    el.dataset.value = String(value);
    if (prefersReduced.matches || from === value){ el.textContent = fmt(value); return; }
    const start = performance.now(), dur = from === 0 ? 1200 : 700;
    function tick(now){
        const t = Math.min(1, (now - start) / dur), e = 1 - Math.pow(1 - t, 3);
        el.textContent = fmt(Math.round(from + (value - from) * e));
        if (t < 1) el._raf = requestAnimationFrame(tick);
    }
    el._raf = requestAnimationFrame(tick);
}

function renderStatsNote(){
    const note = $('#roblox-stats-updated');
    if (!note) return;
    if (lastSnapshot && lastSnapshot.updatedAt){
        const d = new Date(lastSnapshot.updatedAt);
        if (!isNaN(d)){
            note.textContent = tr('stats_updated')(d.toLocaleTimeString(locale(), { hour:'2-digit', minute:'2-digit' }));
            return;
        }
    }
    note.textContent = statsFailed ? tr('stats_unavailable') : tr('stats_loading');
}

function renderStats(snap){
    const tot = { playing:null, visits:null, likes:null, favorites:null };
    for (const key of Object.keys(PLACES)){
        const g = snap.games?.[key] || {};
        const v = { playing:num(g.playing), visits:num(g.visits), likes:num(g.likes), favorites:num(g.favorites) };
        setNumber(`${key}-players`, v.playing);
        setNumber(`${key}-visits`,  v.visits);
        setNumber(`${key}-likes`,   v.likes);
        setNumber(`${key}-favs`,    v.favorites);
        FIELDS.forEach(f => { if (v[f] !== null) tot[f] = (tot[f] || 0) + v[f]; });
    }
    setNumber('stat-players', tot.playing);
    setNumber('stat-likes',   tot.likes);
    setNumber('stat-favs',    tot.favorites);
    setNumber('stat-visits',  tot.visits);
}

async function refreshRobloxStats(){
    clearTimeout(statsTimer);
    let delay = STATS_INTERVAL;
    if (!document.hidden){
        const prev = lastSnapshot || store.get('neox-stats');
        let snap = null;
        try { snap = await fetchLive(); } catch (e) { console.warn('[NeoX] Stats ao vivo falharam:', e.message || e); }
        if (hasData(snap)){
            snap = mergeSnapshot(snap, prev);
        } else {
            try {
                const s = await fetchJSON(new URL('roblox-stats.json', document.baseURI).href);
                snap = hasData(s) ? mergeSnapshot(s, prev) : null;
            } catch (e) { snap = null; }
            delay = 60000; // ao vivo falhou: tenta de novo em 1 min
        }
        if (!hasData(snap) && hasData(prev)) snap = prev;
        if (hasData(snap)){
            store.set('neox-stats', snap);
            lastSnapshot = snap; statsFailed = false; renderStats(snap);
        } else { statsFailed = true; renderStats({ games:{} }); }
        renderStatsNote();
    }
    statsTimer = setTimeout(refreshRobloxStats, delay + Math.random() * 1500);
}
document.addEventListener('visibilitychange', () => { if (!document.hidden){ refreshRobloxStats(); refreshCommunity(); } });

/* =========================================================
   9. COMUNIDADE: grupo do Roblox + servidor do Discord
   ========================================================= */
let community = store.get('neox-community') || { group:null, discord:null, online:null };
let communityTimer = null;

function renderCommunity(){
    setNumber('grp-members', num(community.group));
    setNumber('dc-members',  num(community.discord));
    setNumber('dc-online',   num(community.online));
}
async function refreshCommunity(){
    clearTimeout(communityTimer);
    if (!document.hidden){
        const [g, d] = await Promise.allSettled([
            fetchJSON(`https://groups.roproxy.com/v1/groups/${ROBLOX_GROUP_ID}`),
            fetchJSON(`https://discord.com/api/v10/invites/${DISCORD_INVITE}?with_counts=true`)
        ]);
        if (g.status === 'fulfilled' && num(g.value.memberCount) !== null) community.group = num(g.value.memberCount);
        if (d.status === 'fulfilled'){
            if (num(d.value.approximate_member_count) !== null) community.discord = num(d.value.approximate_member_count);
            if (num(d.value.approximate_presence_count) !== null) community.online = num(d.value.approximate_presence_count);
        }
        store.set('neox-community', community);
        renderCommunity();
    }
    communityTimer = setTimeout(refreshCommunity, COMMUNITY_INTERVAL);
}

/* =========================================================
   10. CARROSSEL DA EQUIPE (loop infinito, arraste e teclado)
   ========================================================= */
(function(){
    const track = $('#team-carousel'), viewport = $('#team-viewport');
    const dotsRoot = $('#team-dots'), status = $('#team-status');
    if (!track || !viewport) return;
    const total = TEAM.length;
    const COPIES = 3;                // 3 cópias: sempre existe card dos dois lados
    let index = total;               // começa no primeiro (SasaDev) da cópia do meio
    let dragging = false, startX = 0, dx = 0, pointerId = null, moved = false, suppressClick = false;

    function buildCard(m, isClone){
        const card = document.createElement('div');
        card.className = 'glass-card team-card';
        const avatar = document.createElement('div'); avatar.className = 'team-avatar';
        const img = document.createElement('img');
        img.src = m.img; img.alt = m.name; img.width = 380; img.height = 256; img.loading = 'lazy'; img.decoding = 'async'; img.draggable = false;
        img.addEventListener('error', () => { img.style.display = 'none'; });
        avatar.appendChild(img);
        const top = document.createElement('div');
        const h3 = document.createElement('h3'); h3.textContent = m.name;
        const role = document.createElement('p'); role.className = 'team-role'; role.dataset.i18n = m.role;
        top.append(h3, role);
        const wrap = document.createElement('div');
        wrap.append(avatar, top);
        card.appendChild(wrap);
        if (m.id){
            const a = document.createElement('a');
            a.className = 'team-link'; a.target = '_blank'; a.rel = 'noopener noreferrer';
            a.href = `https://www.roblox.com/users/${m.id}/profile`;
            a.innerHTML = '<i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i> <span data-i18n="profile"></span>';
            card.appendChild(a);
        }
        if (isClone){
            card.setAttribute('aria-hidden', 'true'); card.inert = true;
        }
        return card;
    }

    const frag = document.createDocumentFragment();
    for (let c = 0; c < COPIES; c++) TEAM.forEach(m => frag.appendChild(buildCard(m, c !== 1)));
    track.appendChild(frag);
    const cards = Array.from(track.children);

    const dots = TEAM.map((m, i) => {
        const d = document.createElement('button');
        d.type = 'button'; d.className = 'team-dot'; d.setAttribute('aria-current', 'false'); d.setAttribute('aria-label', `${i + 1}: ${m.name}`);
        d.addEventListener('click', () => goToLogical(i));
        dotsRoot.appendChild(d);
        return d;
    });

    const logical = () => ((index % total) + total) % total;
    const xFor = i => viewport.clientWidth / 2 - (cards[i].offsetLeft + cards[i].offsetWidth / 2);
    const setX = x => { track.style.transform = `translate3d(${x}px,0,0)`; };

    function paint(){
        cards.forEach((c, k) => c.classList.toggle('is-active', k === index));
        const l = logical();
        dots.forEach((d, k) => d.setAttribute('aria-current', k === l ? 'true' : 'false'));
        status.textContent = `${l + 1} / ${total} — ${TEAM[l].name}`;
    }
    function place(animated){
        if (!animated){ track.classList.add('no-anim'); }
        setX(xFor(index));
        if (!animated){ track.getBoundingClientRect(); requestAnimationFrame(() => track.classList.remove('no-anim')); }
    }
    // Depois da animação, volta (sem ninguém perceber) para a cópia do meio: é o que faz o ciclo ser infinito
    function normalize(){
        if (index >= total && index < total * 2) return;
        index = index < total ? index + total : index - total;
        paint(); place(false);
    }
    function go(delta){
        index = Math.max(0, Math.min(cards.length - 1, index + delta));
        paint(); place(true);
        if (prefersReduced.matches) normalize();
    }
    function goToLogical(i){
        let diff = i - logical();
        if (diff > total / 2) diff -= total;
        if (diff < -total / 2) diff += total;
        go(diff);
    }

    track.addEventListener('transitionend', e => { if (e.target === track && e.propertyName === 'transform' && !dragging) normalize(); });
    $('#team-prev').addEventListener('click', () => go(-1));
    $('#team-next').addEventListener('click', () => go(1));
    viewport.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight'){ e.preventDefault(); go(1); }
        else if (e.key === 'ArrowLeft'){ e.preventDefault(); go(-1); }
    });

    /* Arrastar / deslizar acompanhando o dedo ou mouse */
    viewport.addEventListener('pointerdown', e => {
        if (e.button !== undefined && e.button !== 0) return;
        if (e.target.closest('a,button')) return;
        normalize();
        pointerId = e.pointerId; startX = e.clientX; dx = 0; moved = false; dragging = false;
    });
    viewport.addEventListener('pointermove', e => {
        if (pointerId !== e.pointerId) return;
        dx = e.clientX - startX;
        if (!dragging && Math.abs(dx) > 6){
            dragging = true; moved = true;
            track.classList.add('is-dragging'); viewport.classList.add('is-dragging');
            try { viewport.setPointerCapture(pointerId); } catch {}
        }
        if (dragging) setX(xFor(index) + dx);
    });
    function endDrag(e){
        if (pointerId !== e.pointerId) return;
        pointerId = null;
        if (!dragging) return;
        dragging = false;
        track.classList.remove('is-dragging'); viewport.classList.remove('is-dragging');
        suppressClick = true; setTimeout(() => { suppressClick = false; }, 60);
        const step = cards[1].offsetLeft - cards[0].offsetLeft || 400;
        let steps = -Math.round(dx / step);
        if (steps === 0 && Math.abs(dx) > 40) steps = dx < 0 ? 1 : -1;
        steps = Math.max(-3, Math.min(3, steps));
        if (steps) go(steps); else place(true);
    }
    viewport.addEventListener('pointerup', endDrag);
    viewport.addEventListener('pointercancel', endDrag);
    // Clicar num card lateral traz ele para o centro; depois de arrastar, não dispara clique
    viewport.addEventListener('click', e => {
        if (suppressClick){ e.preventDefault(); e.stopPropagation(); return; }
        if (e.target.closest('a,button')) return;
        const card = e.target.closest('.team-card');
        if (!card) return;
        const i = cards.indexOf(card);
        if (i !== -1 && i !== index) go(i - index);
    }, true);

    window.addEventListener('resize', () => place(false), { passive:true });
    window.addEventListener('load', () => place(false));
    paint();
    place(false);
})();

/* =========================================================
   11. FORMULÁRIO
   ========================================================= */
$('#contact-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const status = $('#form-status'), btn = form.querySelector('[type="submit"]');
    status.classList.remove('is-error');
    if (form.elements._honey?.value) return; // robô
    const endpoint = CONTACT_WORKER_URL || (FORMSUBMIT_ID ? `https://formsubmit.co/ajax/${FORMSUBMIT_ID}` : '');
    if (!endpoint){ status.textContent = tr('form_inactive'); status.classList.add('is-error'); return; }
    const payload = {
        name: form.elements.name.value, email: form.elements.email.value,
        roblox: form.elements.roblox.value, message: form.elements.message.value,
        _subject: form.elements._subject?.value, _template: form.elements._template?.value
    };
    btn.disabled = true; status.textContent = tr('sending');
    try {
        const res = await fetch(endpoint, { method:'POST', headers:{ 'Content-Type':'application/json', 'Accept':'application/json' }, body:JSON.stringify(payload) });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || data.success === false || data.success === 'false') throw new Error(data.message || 'send failed');
        status.textContent = tr('sent'); form.reset();
    } catch (err){
        console.warn('[NeoX] Falha ao enviar formulário:', err.message || err);
        status.textContent = tr('send_error'); status.classList.add('is-error');
    } finally { btn.disabled = false; }
});

/* =========================================================
   12. LOGO DO HERO (fallback visível)
   ========================================================= */
(function(){
    const box = $('#hero-logo'), img = box && $('img', box);
    if (!img) return;
    const fail = () => box.classList.add('is-fallback');
    img.addEventListener('error', fail);
    if (img.complete && img.naturalWidth === 0) fail();
})();

/* =========================================================
   INÍCIO
   ========================================================= */
store.del('neox-universes'); store.del('neox-universes-v2'); // limpa caches antigos uma única vez
applyLanguage(currentLang);
renderCommunity();
refreshRobloxStats();
refreshCommunity();
